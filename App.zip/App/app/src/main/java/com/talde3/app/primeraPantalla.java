package com.talde3.app;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class primeraPantalla extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_primera_pantalla);
    }
}